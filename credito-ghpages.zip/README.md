# Inteligência de Crédito

App pessoal de análise de crédito privado e mercado de capitais.

Hospedado via GitHub Pages — acesse pelo link do seu repositório.

## Como atualizar

Quando receber um novo `index.html`:
1. Substitua o arquivo aqui no repositório
2. Commit + push
3. Em ~1 minuto o site já está atualizado
